export const sliderImages = [
  "/assets/test.jpg",
  "/assets/iphone6.jpeg",
  "/assets/iphone4.jpeg",
  "/assets/iphone5.webp",
  "/assets/iphone7.webp",
];
