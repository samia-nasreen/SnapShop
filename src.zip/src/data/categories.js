export const categories = [
  { icon: "smartphone.png", label: "Phones" },
  { icon: "computer.png", label: "Computers" },
  { icon: "smartwatch.png", label: "SmartWatch" },
  { icon: "camera.png", label: "Camera" },
  { icon: "headphones.png", label: "HeadPhones" },
  { icon: "gaming.png", label: "Gaming" },
];
