export const stats = [
  {
    icon: "shop_icon.svg",
    label: "10.5k",
    description: "Sellers active on our site",
  },
  { icon: "sale_icon.svg", label: "33k", description: "Monthly Product Sale" },
  {
    icon: "shoppingbag_icon.svg",
    label: "45.5k",
    description: "Customers active on our site",
  },
  {
    icon: "moneybag_icon.svg",
    label: "25k",
    description: "Annual gross sale on our site",
  },
];
